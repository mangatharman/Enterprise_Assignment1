const router = require('express').Router();
let User = require('../models/user.model');

router.route('/').get((req, res) => {
    User.find()
        .then(users => res.json(users))
        .catch(err => res.status(400).json('Error: ' + err));
});

//Adding a User
router.route('/add').post((req, res) => {
    const stuId = req.body.stuId;
    const student_name = req.body.student_name;
    const student_number = req.body.student_number;
    const student_age = req.body.student_age;

    const newUser = User({stuId, student_name, student_number, student_age});

    newUser.save()
        .then(() => res.json('User added!'))
        .catch(err => res.status(400).json('Error: ' + err));
    
});

//Deleting a User
router.route('/:id').delete((req, res) => {
    User.findByIdAndDelete(req.params.stuId)
        .then(() => res.json('User Deleted!'))
        .catch(err => res.status(400).json('Error' + err));
});

//Updating a User
router.route('/update').put((req, res) => {
    User.findById(req.params.stuId).then(user => {
        user.stuId = req.body.stuId,
        user.student_name = req.body.student_name,
        user.student_age = req.body.student_age,
        user.student_number = req.body.student_number;
        user.save();
    }).then(res.send("Student Updated"))
        .catch(err => res.status(400).json('Error '+ err));
});



module.exports = router;